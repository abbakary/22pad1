document.addEventListener('DOMContentLoaded', function() {
    // Auto-format phone number
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 9) value = value.substring(0, 9);
            e.target.value = value;
        });
    }

    // Customer type dynamic fields
    const customerTypeSelect = document.querySelector('select[name="customer_type"]');
    if (customerTypeSelect) {
        function toggleCustomerTypeFields() {
            const selectedType = customerTypeSelect.value;
            
            // Get conditional field elements
            const organizationField = document.getElementById('organization-field');
            const taxField = document.getElementById('tax-field');
            const personalSubtypeField = document.getElementById('personal-subtype-field');
            
            // Hide all conditional fields first
            [organizationField, taxField, personalSubtypeField].forEach(field => {
                if (field) {
                    field.style.display = 'none';
                    // Remove required attribute from hidden fields
                    const inputs = field.querySelectorAll('input, select, textarea');
                    inputs.forEach(input => input.removeAttribute('required'));
                }
            });

            // Show relevant fields based on customer type
            if (selectedType === 'personal') {
                // Show personal subtype field for personal customers
                if (personalSubtypeField) {
                    personalSubtypeField.style.display = 'block';
                    const subtypeSelect = personalSubtypeField.querySelector('select');
                    if (subtypeSelect) subtypeSelect.setAttribute('required', 'required');
                }
            } else if (['government', 'ngo', 'company'].includes(selectedType)) {
                // Show organization and tax fields for organizational customers
                if (organizationField) {
                    organizationField.style.display = 'block';
                    const orgInput = organizationField.querySelector('input');
                    if (orgInput) orgInput.setAttribute('required', 'required');
                }
                if (taxField) {
                    taxField.style.display = 'block';
                    const taxInput = taxField.querySelector('input');
                    if (taxInput) taxInput.setAttribute('required', 'required');
                }
            }
            // For 'bodaboda' type, no additional fields are required
            
            // Add visual feedback for field changes with smooth animations
            setTimeout(() => {
                [organizationField, taxField, personalSubtypeField].forEach(field => {
                    if (field && field.style.display === 'block') {
                        field.classList.add('animate-in');
                        // Remove animation class after animation completes
                        setTimeout(() => field.classList.remove('animate-in'), 400);
                    }
                });
            }, 50);
        }

        // Initialize on page load
        toggleCustomerTypeFields();
        
        // Handle changes
        customerTypeSelect.addEventListener('change', toggleCustomerTypeFields);
    }

    // Intent selection enhancement
    const intentCards = document.querySelectorAll('.intent-card');
    const intentRadios = document.querySelectorAll('input[name="intent"]');
    
    if (intentCards.length > 0) {
        // Add click handlers to cards
        intentCards.forEach(card => {
            card.addEventListener('click', function() {
                const radio = this.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                    updateIntentCardStyles();
                }
            });
        });

        // Add change handlers to radio buttons
        intentRadios.forEach(radio => {
            radio.addEventListener('change', updateIntentCardStyles);
        });

        function updateIntentCardStyles() {
            intentCards.forEach(card => {
                const radio = card.querySelector('input[type="radio"]');
                if (radio && radio.checked) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            });
        }

        // Initialize on page load
        updateIntentCardStyles();
    }

    // Service and Sales card selection
    const serviceCards = document.querySelectorAll('.service-check-card');
    const salesCards = document.querySelectorAll('.sales-check-card');
    
    function handleCheckCardClick(cards) {
        cards.forEach(card => {
            card.addEventListener('click', function() {
                const checkbox = this.querySelector('input[type="checkbox"]');
                const radio = this.querySelector('input[type="radio"]');
                
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                } else if (radio) {
                    radio.checked = true;
                }
                
                updateCheckCardStyles(cards);
            });
        });
    }
    
    function updateCheckCardStyles(cards) {
        cards.forEach(card => {
            const input = card.querySelector('input[type="checkbox"], input[type="radio"]');
            if (input && input.checked) {
                card.classList.add('selected');
            } else {
                card.classList.remove('selected');
            }
        });
    }
    
    if (serviceCards.length > 0) {
        handleCheckCardClick(serviceCards);
        updateCheckCardStyles(serviceCards);
    }
    
    if (salesCards.length > 0) {
        handleCheckCardClick(salesCards);
        updateCheckCardStyles(salesCards);
    }

    // Dynamic service type loading
    const serviceTypeRadios = document.querySelectorAll('input[name="service_type"]');
    const serviceDetails = document.getElementById('service-details');
    
    if (serviceTypeRadios.length && serviceDetails) {
        serviceTypeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.checked) {
                    const serviceType = this.value;
                    fetch(`/service-form/${serviceType}/`)
                        .then(response => response.text())
                        .then(html => {
                            serviceDetails.innerHTML = html;
                            // Re-initialize any dynamic elements if needed
                        })
                        .catch(error => console.error('Error loading service form:', error));
                }
            });
        });
    }

    // Form validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (!isValid) {
                e.preventDefault();
                // Scroll to first invalid field
                const firstInvalid = form.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        });
    }

    // Auto-save form data
    function saveFormData() {
        if (!form) return;
        
        const formData = new FormData(form);
        const formObject = {};
        formData.forEach((value, key) => {
            formObject[key] = value;
        });
        
        localStorage.setItem('customerRegistrationData', JSON.stringify(formObject));
    }

    // Load saved form data
    function loadFormData() {
        const savedData = localStorage.getItem('customerRegistrationData');
        if (!savedData) return;
        
        try {
            const formData = JSON.parse(savedData);
            Object.keys(formData).forEach(key => {
                const element = form.querySelector(`[name="${key}"]`);
                if (element) {
                    if (element.type === 'checkbox' || element.type === 'radio') {
                        element.checked = formData[key] === 'true' || formData[key] === element.value;
                    } else {
                        element.value = formData[key];
                    }
                }
            });
        } catch (e) {
            console.error('Error loading form data:', e);
            localStorage.removeItem('customerRegistrationData');
        }
    }

    // Set up auto-save
    if (form) {
        // Load saved data on page load
        loadFormData();
        
        // Save on input change
        form.addEventListener('input', saveFormData);
        
        // Clear saved data on successful form submission
        form.addEventListener('submit', function() {
            localStorage.removeItem('customerRegistrationData');
        });
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
