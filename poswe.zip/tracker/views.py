from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.db.models import Count, Avg, Q, Sum
from django.utils import timezone
from django.contrib.auth.views import LoginView
from django.urls import reverse
from django.contrib import messages
from django.db.models.functions import TruncDate
from django.core.cache import cache
import json
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User, Group
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render, reverse
from django.contrib import messages
from .models import Customer, Order, Vehicle, InventoryItem, CustomerNote
from .forms import VehicleForm
from .forms import (
    CustomerStep1Form,
    CustomerStep2Form,
    CustomerStep3Form,
    CustomerStep4Form,
    VehicleForm,
    OrderForm,
    CustomerEditForm,
    SystemSettingsForm,
)
from .utils import add_audit_log, get_audit_logs, clear_audit_logs


from django.contrib.auth.views import LogoutView
from django.views.generic import View

class CustomLoginView(LoginView):
    template_name = "registration/login.html"

class CustomLogoutView(View):
    def get(self, request, *args, **kwargs):
        from django.contrib.auth import logout
        logout(request)
        return redirect('tracker:login')
        
    def post(self, request, *args, **kwargs):
        from django.contrib.auth import logout
        logout(request)
        return redirect('tracker:login')

    def form_valid(self, form):
        response = super().form_valid(form)
        remember = self.request.POST.get("remember")
        if not remember:
            self.request.session.set_expiry(0)
        else:
            self.request.session.set_expiry(60 * 60 * 24 * 14)
        try:
            from .signals import _client_ip  # reuse helper
            ip = _client_ip(self.request)
            ua = (self.request.META.get('HTTP_USER_AGENT') or '')[:200]
            add_audit_log(self.request.user, 'login', f'Login at {timezone.localtime().strftime("%Y-%m-%d %H:%M:%S")} from {ip or "?"} UA: {ua}')
        except Exception:
            pass
        return response

    def get_success_url(self):
        user = self.request.user
        # Admins land on dashboard
        if user.is_superuser:
            return reverse('tracker:dashboard')
        # Managers land on orders list (operational focus)
        if user.groups.filter(name='manager').exists():
            return reverse('tracker:orders_list')
        # Staff (non-admin) to users list, otherwise dashboard
        if user.is_staff:
            return reverse('tracker:users_list')
        return reverse('tracker:dashboard')


@login_required
def dashboard(request: HttpRequest):
    cache_key = "dashboard_metrics_v1"
    cached = cache.get(cache_key)
    if cached:
        (
            total_orders,
            total_customers,
            status_counts,
            type_counts,
            priority_counts,
            completed_today_count,
            trend_labels,
            trend_values,
            total_stock,
        ) = cached
    else:
        total_orders = Order.objects.count()
        total_customers = Customer.objects.count()
        status_counts_qs = Order.objects.values("status").annotate(c=Count("id"))
        type_counts_qs = Order.objects.values("type").annotate(c=Count("id"))
        priority_counts_qs = Order.objects.values("priority").annotate(c=Count("id"))
        status_counts = {x["status"]: x["c"] for x in status_counts_qs}
        type_counts = {x["type"]: x["c"] for x in type_counts_qs}
        priority_counts = {x["priority"]: x["c"] for x in priority_counts_qs}
        today = timezone.localdate()
        completed_today_count = Order.objects.filter(status="completed", completed_at__date=today).count()
        dates = [today - timezone.timedelta(days=i) for i in range(13, -1, -1)]
        trend_qs = (
            Order.objects.annotate(day=TruncDate("created_at")).values("day").annotate(c=Count("id"))
        )
        trend_map = {row["day"]: row["c"] for row in trend_qs}
        trend_labels = [d.strftime("%Y-%m-%d") for d in dates]
        trend_values = [trend_map.get(d, 0) for d in dates]
        total_stock = InventoryItem.objects.aggregate(total=Sum('quantity'))['total'] or 0
        cache.set(cache_key, (
            total_orders,
            total_customers,
            status_counts,
            type_counts,
            priority_counts,
            completed_today_count,
            trend_labels,
            trend_values,
            total_stock,
        ), 60)

    today = timezone.localdate()
    pending_count = status_counts.get("created", 0)
    in_progress_count = status_counts.get("in_progress", 0)
    active_count = status_counts.get("created", 0) + status_counts.get("assigned", 0) + status_counts.get("in_progress", 0)
    
    # Get today's customers (max 5)
    todays_customers = Customer.objects.filter(
        registration_date__date=today
    ).order_by('-registration_date')[:5]
    
    # Get recent orders
    recent_orders = (
        Order.objects.select_related("customer", "vehicle")
        .exclude(status="completed")
        .order_by("-created_at")[:10]
    )
    
    # Get overdue inventory items (items with quantity below threshold)
    OVERDUE_THRESHOLD = 5  # Define your threshold for overdue items
    overdue_inventory = (
        InventoryItem.objects
        .filter(quantity__lte=OVERDUE_THRESHOLD)
        .order_by('quantity')[:10]  # Get top 10 most critical items
    )
    
    inventory_preview = InventoryItem.objects.order_by("-created_at")[:10]
    can_manage_inventory = (request.user.is_superuser or request.user.groups.filter(name='manager').exists())
    completed = status_counts.get("completed", 0)
    completed_percent = int((completed * 100) / total_orders) if total_orders else 0
    
    # Get order statistics for the last 7 days
    date_range = [today - timezone.timedelta(days=i) for i in range(6, -1, -1)]
    order_stats = (
        Order.objects.filter(created_at__date__in=date_range)
        .values('created_at__date')
        .annotate(count=Count('id'))
        .order_by('created_at__date')
    )
    
    # Get top clients (customers with most orders) with their latest order date
    from django.db.models import Prefetch, Max, F
    
    # Get the top 5 customers with their order count and latest order date in a single query
    top_clients = (
        Customer.objects
        .annotate(
            order_count=Count('orders'),
            latest_order_date=Max('orders__created_at')
        )
        .filter(order_count__gt=0)
        .order_by('-order_count')[:5]  # Get top 5 clients
    )
    
    # Create a dictionary of date: count
    order_stats_dict = {stat['created_at__date']: stat['count'] for stat in order_stats}
    
    # Fill in missing dates with 0
    order_stats_data = [order_stats_dict.get(date, 0) for date in date_range]
    order_dates = [date.strftime('%a, %b %d') for date in date_range]
    charts = {
        "status": {
            "labels": ["Created", "Assigned", "In Progress", "Completed", "Cancelled"],
            "values": [
                status_counts.get("created", 0),
                status_counts.get("assigned", 0),
                status_counts.get("in_progress", 0),
                status_counts.get("completed", 0),
                status_counts.get("cancelled", 0),
            ],
        },
        "type": {
            "labels": ["Service", "Sales", "Consultation"],
            "values": [
                type_counts.get("service", 0),
                type_counts.get("sales", 0),
                type_counts.get("consultation", 0),
            ],
        },
        "priority": {
            "labels": ["Low", "Medium", "High", "Urgent"],
            "values": [
                priority_counts.get("low", 0),
                priority_counts.get("medium", 0),
                priority_counts.get("high", 0),
                priority_counts.get("urgent", 0),
            ],
        },
        "trend": {"labels": trend_labels, "values": trend_values},
    }

    return render(
        request,
        "tracker/dashboard.html",
        {
            "total_orders": total_orders,
            "total_customers": total_customers,
            "pending_count": pending_count,
            "in_progress_count": in_progress_count,
            "completed_today_count": completed_today_count,
            "active_count": active_count,
            "status_counts": status_counts,
            "type_counts": type_counts,
            "recent_orders": recent_orders,
            "todays_customers": todays_customers,
            "completed_percent": completed_percent,
            "charts_json": json.dumps(charts),
            "inventory_preview": inventory_preview,
            "can_manage_inventory": can_manage_inventory,
            "total_stock": total_stock,
            "order_stats_data": order_stats_data,
            "order_dates": json.dumps([str(date) for date in order_dates]),
            "overdue_inventory": overdue_inventory,
            "overdue_threshold": OVERDUE_THRESHOLD,
            "top_clients": top_clients,
        },
    )


@login_required
def customers_list(request: HttpRequest):
    from django.db.models import Q
    q = request.GET.get('q','').strip()
    f_type = request.GET.get('type','').strip()
    f_status = request.GET.get('status','').strip()

    qs = Customer.objects.all().order_by('-registration_date')
    if q:
        qs = qs.filter(
            Q(full_name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q) | Q(code__icontains=q)
        )
    if f_type:
        qs = qs.filter(customer_type=f_type)
    if f_status == 'active':
        qs = qs.filter(total_visits__gt=0)
    elif f_status == 'inactive':
        qs = qs.filter(total_visits__lte=0)

    # Stats
    today = timezone.localdate()
    active_customers = Customer.objects.filter(arrival_time__date=today).count()
    new_customers_today = Customer.objects.filter(registration_date__date=today).count()
    returning_customers = Customer.objects.filter(total_visits__gt=1).count()

    paginator = Paginator(qs, 20)
    page = request.GET.get('page')
    customers = paginator.get_page(page)
    return render(request, "tracker/customers_list.html", {
        "customers": customers,
        "q": q,
        "active_customers": active_customers,
        "new_customers_today": new_customers_today,
        "returning_customers": returning_customers,
    })


@login_required
def customers_search(request: HttpRequest):
    q = request.GET.get("q", "").strip()
    customer_id = request.GET.get("id")
    recent = request.GET.get("recent")
    details = request.GET.get("details")

    results = []

    if customer_id:
        try:
            customer = Customer.objects.get(id=customer_id)
            results = [customer]
        except Customer.DoesNotExist:
            pass
    elif recent:
        results = Customer.objects.all().order_by('-last_visit', '-registration_date')[:10]
    elif q:
        results = Customer.objects.filter(
            Q(full_name__icontains=q) |
            Q(phone__icontains=q) |
            Q(email__icontains=q) |
            Q(code__icontains=q)
        ).order_by('-last_visit', '-registration_date')[:20]

    data = []
    for c in results:
        item = {
            "id": c.id,
            "code": c.code,
            "name": c.full_name,
            "phone": c.phone,
            "email": c.email or '',
            "type": c.customer_type or 'personal',
            "customer_type_display": c.get_customer_type_display() if c.customer_type else 'Personal',
            "last_visit": c.last_visit.isoformat() if c.last_visit else None,
            "total_visits": c.total_visits,
            "address": c.address or '',
        }
        if details and customer_id:
            item.update({
                "organization_name": c.organization_name or '',
                "tax_number": c.tax_number or '',
                "personal_subtype": c.personal_subtype or '',
                "current_status": c.current_status or '',
                "registration_date": c.registration_date.isoformat() if c.registration_date else None,
                "vehicles": [
                    {"id": v.id, "plate_number": v.plate_number, "make": v.make or '', "model": v.model or ''}
                    for v in c.vehicles.all()
                ],
                "orders": [
                    {"id": o.id, "order_number": o.order_number, "type": o.type, "status": o.status, "created_at": o.created_at.isoformat()}
                    for o in c.orders.order_by('-created_at')[:5]
                ],
            })
        data.append(item)
    return JsonResponse({"results": data})


@login_required
def customer_detail(request: HttpRequest, pk: int):
    c = get_object_or_404(Customer, pk=pk)
    vehicles = c.vehicles.all()
    orders = c.orders.order_by("-created_at")[:20]
    return render(request, "tracker/customer_detail.html", {
        'customer': c,
        'vehicles': vehicles,
        'orders': orders,
        'page_title': c.full_name,
    })


@login_required
def add_customer_note(request: HttpRequest, pk: int):
    """Add or update a note on a customer's profile"""
    customer = get_object_or_404(Customer, pk=pk)
    note_id = request.POST.get('note_id')
    
    if request.method == 'POST':
        note_content = request.POST.get('note', '').strip()
        if note_content:
            try:
                if note_id:  # Update existing note
                    note = get_object_or_404(CustomerNote, id=note_id, customer=customer)
                    note.content = note_content
                    note.save()
                    action = 'updated'
                else:  # Create new note
                    note = CustomerNote.objects.create(
                        customer=customer,
                        content=note_content,
                        created_by=request.user
                    )
                    action = 'added'
                
                # Log the action
                add_audit_log(
                    user=request.user,
                    action_type=f'customer_note_{action}',
                    description=f'{action.capitalize()} a note for customer {customer.full_name}',
                    customer_id=customer.id,
                    note_id=note.id
                )
                
                messages.success(request, f'Note {action} successfully.')
            except Exception as e:
                messages.error(request, f'Error saving note: {str(e)}')
        else:
            messages.error(request, 'Note content cannot be empty.')
    
    # Redirect back to the customer detail page
    return redirect('tracker:customer_detail', pk=customer.id)


def delete_customer_note(request: HttpRequest, customer_id: int, note_id: int):
    """Delete a customer note"""
    if request.method == 'POST':
        try:
            note = get_object_or_404(CustomerNote, id=note_id, customer_id=customer_id)
            
            # Log the action before deletion
            add_audit_log(
                user=request.user,
                action_type='customer_note_deleted',
                description=f'Deleted a note for customer {note.customer.full_name}',
                customer_id=customer_id,
                note_id=note_id
            )
            
            note.delete()
            return JsonResponse({'success': True})
            
        except Exception as e:
            return JsonResponse(
                {'success': False, 'error': str(e)}, 
                status=400
            )
    
    return JsonResponse(
        {'success': False, 'error': 'Invalid request method'}, 
        status=405
    )


@login_required
def customer_register(request: HttpRequest):
    step = int(request.POST.get("step", request.GET.get("step", 1)))
    if request.method == "POST":
        if step == 1:
            form = CustomerStep1Form(request.POST)
            action = request.POST.get("action")
            if form.is_valid():
                if action == "save_customer":
                    data = form.cleaned_data
                    c = Customer.objects.create(
                        full_name=data.get("full_name"),
                        phone=data.get("phone"),
                        email=data.get("email"),
                        address=data.get("address"),
                        notes=data.get("notes"),
                    )
                    messages.success(request, "Customer saved successfully")
                    return redirect("tracker:customer_detail", pk=c.id)
                # Continue to next step
                request.session["reg_step1"] = form.cleaned_data
                request.session.save()
                return redirect(f"{reverse('tracker:customer_register')}?step=2")
        elif step == 2:
            form = CustomerStep2Form(request.POST)
            if form.is_valid():
                request.session["reg_step2"] = form.cleaned_data
                request.session.save()
                intent = form.cleaned_data.get("intent")
                # If inquiry, skip service type selection and go to step 4
                next_step = 4 if intent == "inquiry" else 3
                return redirect(f"{reverse('tracker:customer_register')}?step={next_step}")
        elif step == 3:
            form = CustomerStep3Form(request.POST)
            if form.is_valid():
                request.session["reg_step3"] = form.cleaned_data
                request.session.save()
                return redirect(f"{reverse('tracker:customer_register')}?step=4")
        elif step == 4:
            form = CustomerStep4Form(request.POST)
            if form.is_valid():
                # Get all session data
                step1_data = request.session.get("reg_step1", {})
                step2_data = request.session.get("reg_step2", {})
                step3_data = request.session.get("reg_step3", {})
                
                # Validate that we have required data
                if not step1_data.get("full_name"):
                    messages.error(request, "Missing customer information. Please start from Step 1.")
                    return redirect(f"{reverse('tracker:customer_register')}?step=1")
                
                # Create customer with all data (customer type info is now in step1_data)
                data = {**step1_data, **form.cleaned_data}
                c = Customer.objects.create(
                    full_name=data.get("full_name"),
                    phone=data.get("phone"),
                    email=data.get("email"),
                    address=data.get("address"),
                    notes=data.get("notes") or data.get("additional_notes"),
                    customer_type=data.get("customer_type"),
                    organization_name=data.get("organization_name"),
                    tax_number=data.get("tax_number"),
                    personal_subtype=data.get("personal_subtype"),
                )
                
                # Create vehicle if car service was selected
                v = None
                intent = step2_data.get("intent")
                service_type = step3_data.get("service_type")
                
                if intent == "service" and service_type == "car_service":
                    plate_number = request.POST.get("plate_number")
                    make = request.POST.get("make")
                    model = request.POST.get("model")
                    vehicle_type = request.POST.get("vehicle_type")
                    
                    if plate_number or make or model:
                        v = Vehicle.objects.create(
                            customer=c,
                            plate_number=plate_number,
                            make=make,
                            model=model,
                            vehicle_type=vehicle_type
                        )
                
                # Create order based on intent and service type
                o = None
                if intent == "service" and service_type == "tire_sales":
                    # Tire sales order
                    item_name = request.POST.get("item_name")
                    brand = request.POST.get("brand")
                    quantity = request.POST.get("quantity")
                    tire_type = request.POST.get("tire_type")
                    
                    if item_name and brand and quantity:
                        # Check inventory
                        inv_check_ok = True
                        qty_int = int(quantity)
                        item = InventoryItem.objects.filter(name=item_name, brand=brand).first()
                        if not item:
                            messages.error(request, 'Item not found in inventory')
                            inv_check_ok = False
                        elif item.quantity < qty_int:
                            messages.error(request, f'Only {item.quantity} in stock for {item_name} ({brand})')
                            inv_check_ok = False
                        
                        if not inv_check_ok:
                            context = {"step": 4, "form": form}
                            context.update({"step1": step1_data, "step2": step2_data, "step3": step3_data})
                            return render(request, "tracker/customer_register.html", context)
                        
                        o = Order.objects.create(
                            customer=c,
                            vehicle=v,
                            type="sales",
                            item_name=item_name,
                            brand=brand,
                            quantity=qty_int,
                            tire_type=tire_type,
                            status="created",
                            description=f"Tire Sales: {item_name} ({brand}) - {tire_type}"
                        )
                        
                        # Adjust inventory
                        from .utils import adjust_inventory
                        adjust_inventory(item_name, brand, -qty_int)
                        
                elif intent == "service" and service_type == "car_service":
                    # Car service order
                    o = Order.objects.create(
                        customer=c,
                        vehicle=v,
                        type="service",
                        status="created",
                        description="Car Service"
                    )
                    
                elif intent == "inquiry":
                    # Inquiry order
                    inquiry_type = request.POST.get("inquiry_type")
                    questions = request.POST.get("questions")
                    contact_preference = request.POST.get("contact_preference")
                    followup_date = request.POST.get("followup_date")
                    
                    o = Order.objects.create(
                        customer=c,
                        vehicle=v,
                        type="consultation",
                        status="created",
                        description=f"Inquiry: {inquiry_type} - {questions}",
                        inquiry_type=inquiry_type,
                        questions=questions,
                        contact_preference=contact_preference,
                        follow_up_date=followup_date if followup_date else None
                    )
                
                # Clear session data
                for key in ["reg_step1", "reg_step2", "reg_step3"]:
                    request.session.pop(key, None)
                    
                messages.success(request, "Customer registered and order created successfully")
                return redirect("tracker:customer_detail", pk=c.id)
            else:
                messages.error(request, "Please correct the highlighted errors and try again")
    # GET or invalid POST
    context = {"step": step}
    # Read previously selected intent for conditional rendering
    session_step2 = request.session.get("reg_step2", {}) or {}
    intent = session_step2.get("intent")
    context["intent"] = intent
    
    # Include previous steps for all steps (for conditional rendering)
    context["step1"] = request.session.get("reg_step1", {})
    context["step2"] = session_step2
    context["step3"] = request.session.get("reg_step3", {})
    
    if step == 1:
        context["form"] = CustomerStep1Form(initial=request.session.get("reg_step1"))
    elif step == 2:
        context["form"] = CustomerStep2Form(initial=session_step2)
    elif step == 3:
        context["form"] = CustomerStep3Form(initial=request.session.get("reg_step3"))
    else:
        context["form"] = CustomerStep4Form()
        context["vehicle_form"] = VehicleForm()
        # Prefill order type based on intent and selected services
        type_map = {"service": "service", "sales": "sales", "inquiry": "consultation"}
        order_initial = {"type": type_map.get(intent)} if intent in type_map else {}
        sel_services = context["step3"].get("service_type") or []
        if sel_services:
            order_initial["service_selection"] = sel_services
        context["order_form"] = OrderForm(initial=order_initial)
    return render(request, "tracker/customer_register.html", context)


@login_required
def create_order_for_customer(request: HttpRequest, pk: int):
    from .utils import adjust_inventory
    c = get_object_or_404(Customer, pk=pk)
    if request.method == "POST":
        form = OrderForm(request.POST)
        # Ensure vehicle belongs to this customer
        form.fields["vehicle"].queryset = c.vehicles.all()
        if form.is_valid():
            o = form.save(commit=False)
            o.customer = c
            o.status = "created"
            # Inventory check for sales
            if o.type == 'sales':
                name = (o.item_name or '').strip()
                brand = (o.brand or '').strip()
                qty = int(o.quantity or 0)
                from django.db.models import Sum, Q
                if (brand or '').lower() == 'unbranded':
                    available = InventoryItem.objects.filter(name=name).filter(Q(brand__isnull=True) | Q(brand="")).aggregate(total=Sum('quantity')).get('total') or 0
                else:
                    available = InventoryItem.objects.filter(name=name, brand=brand).aggregate(total=Sum('quantity')).get('total') or 0
                if not name or not brand or qty <= 0:
                    messages.error(request, 'Item, brand and valid quantity are required')
                    return render(request, "tracker/order_create.html", {"customer": c, "form": form})
                if available < qty:
                    messages.error(request, f'Only {available} in stock for {name} ({brand})')
                    return render(request, "tracker/order_create.html", {"customer": c, "form": form})
            o.save()
            # Deduct inventory after save
            if o.type == 'sales':
                qty_int = int(o.quantity or 0)
                ok, _, remaining = adjust_inventory(o.item_name, o.brand, -qty_int)
                if ok:
                    messages.success(request, f"Order created. Remaining stock for {o.item_name} ({o.brand}): {remaining}")
                else:
                    messages.warning(request, 'Order created, but inventory not adjusted')
            else:
                messages.success(request, "Order created successfully")
            return redirect("tracker:order_detail", pk=o.id)
        else:
            messages.error(request, "Please fix form errors and try again")
    else:
        form = OrderForm()
        form.fields["vehicle"].queryset = c.vehicles.all()
    return render(request, "tracker/order_create.html", {"customer": c, "form": form})


@login_required
def customer_groups(request: HttpRequest):
    """Advanced customer groups page with detailed analytics and insights"""
    from django.db.models import Count, Sum, Avg, Max, Min, Q, F
    from django.db.models.functions import TruncMonth, TruncWeek
    from datetime import datetime, timedelta
    
    # Get filter parameters
    selected_group = request.GET.get('group', 'all')
    time_period = request.GET.get('period', '6months')
    sort_by = request.GET.get('sort', 'total_spent')
    
    # Calculate time range
    today = timezone.now().date()
    if time_period == '1month':
        start_date = today - timedelta(days=30)
    elif time_period == '3months':
        start_date = today - timedelta(days=90)
    elif time_period == '6months':
        start_date = today - timedelta(days=180)
    elif time_period == '1year':
        start_date = today - timedelta(days=365)
    else:
        start_date = today - timedelta(days=180)  # default
    
    # Base customer queryset with annotations
    customers_base = Customer.objects.annotate(
        recent_orders_count=Count('orders', filter=Q(orders__created_at__date__gte=start_date)),
        last_order_date=Max('orders__created_at'),
        first_order_date=Min('orders__created_at'),
        service_orders=Count('orders', filter=Q(orders__type='service', orders__created_at__date__gte=start_date)),
        sales_orders=Count('orders', filter=Q(orders__type='sales', orders__created_at__date__gte=start_date)),
        consultation_orders=Count('orders', filter=Q(orders__type='consultation', orders__created_at__date__gte=start_date)),
        completed_orders=Count('orders', filter=Q(orders__status='completed', orders__created_at__date__gte=start_date)),
        cancelled_orders=Count('orders', filter=Q(orders__status='cancelled', orders__created_at__date__gte=start_date)),
        vehicles_count=Count('vehicles', distinct=True)
    )
    
    # Customer type groups with detailed analytics
    customer_groups = {}
    
    for customer_type, display_name in Customer.TYPE_CHOICES:
        group_customers = customers_base.filter(customer_type=customer_type)
        
        # Calculate group metrics
        total_customers = group_customers.count()
        if total_customers == 0:
            continue
            
        # Aggregate metrics
        group_stats = group_customers.aggregate(
            total_revenue=Sum('total_spent') or 0,
            avg_revenue_per_customer=Avg('total_spent') or 0,
            total_orders=Sum('recent_orders_count') or 0,
            avg_orders_per_customer=Avg('recent_orders_count') or 0,
            avg_order_value=Avg('total_spent') or 0,
            total_service_orders=Sum('service_orders') or 0,
            total_sales_orders=Sum('sales_orders') or 0,
            total_consultation_orders=Sum('consultation_orders') or 0,
            total_completed_orders=Sum('completed_orders') or 0,
            total_cancelled_orders=Sum('cancelled_orders') or 0,
            total_vehicles=Sum('vehicles_count') or 0,
        )
        
        # Customer segmentation within group
        high_value = group_customers.filter(total_spent__gte=1000).count()
        medium_value = group_customers.filter(total_spent__gte=500, total_spent__lt=1000).count()
        low_value = group_customers.filter(total_spent__lt=500).count()
        
        # Activity levels
        very_active = group_customers.filter(recent_orders_count__gte=5).count()
        active = group_customers.filter(recent_orders_count__gte=2, recent_orders_count__lt=5).count()
        inactive = group_customers.filter(recent_orders_count__lt=2).count()
        
        # Service preferences
        service_preference = group_customers.filter(service_orders__gt=F('sales_orders')).count()
        sales_preference = group_customers.filter(sales_orders__gt=F('service_orders')).count()
        mixed_preference = total_customers - service_preference - sales_preference
        
        # Recent activity trends
        recent_new_customers = group_customers.filter(registration_date__date__gte=start_date).count()
        returning_customers = group_customers.filter(total_visits__gt=1).count()
        
        # Calculate completion rate
        total_orders_for_completion = group_stats['total_orders']
        completion_rate = (group_stats['total_completed_orders'] / total_orders_for_completion * 100) if total_orders_for_completion > 0 else 0
        
        # Get top customers in this group
        top_customers = group_customers.order_by('-total_spent')[:5]
        
        customer_groups[customer_type] = {
            'name': display_name,
            'code': customer_type,
            'total_customers': total_customers,
            'stats': group_stats,
            'segmentation': {
                'high_value': high_value,
                'medium_value': medium_value,
                'low_value': low_value,
            },
            'activity_levels': {
                'very_active': very_active,
                'active': active,
                'inactive': inactive,
            },
            'service_preferences': {
                'service_preference': service_preference,
                'sales_preference': sales_preference,
                'mixed_preference': mixed_preference,
            },
            'trends': {
                'recent_new_customers': recent_new_customers,
                'returning_customers': returning_customers,
                'completion_rate': round(completion_rate, 1),
            },
            'top_customers': top_customers,
        }
    
    # Overall statistics
    overall_stats = customers_base.aggregate(
        total_customers=Count('id'),
        total_revenue=Sum('total_spent') or 0,
        avg_revenue_per_customer=Avg('total_spent') or 0,
        total_orders=Sum('recent_orders_count') or 0,
        avg_orders_per_customer=Avg('recent_orders_count') or 0,
    )
    
    # Get detailed customer list for selected group
    detailed_customers = []
    if selected_group != 'all' and selected_group in dict(Customer.TYPE_CHOICES):
        detailed_customers = customers_base.filter(customer_type=selected_group).order_by(f'-{sort_by}')[:50]
    
    # Monthly trends for charts
    monthly_trends = {}
    for customer_type, display_name in Customer.TYPE_CHOICES:
        monthly_data = (Order.objects
                       .filter(customer__customer_type=customer_type, created_at__date__gte=start_date)
                       .annotate(month=TruncMonth('created_at'))
                       .values('month')
                       .annotate(
                           orders=Count('id'),
                           customers=Count('customer', distinct=True)
                       )
                       .order_by('month'))
        
        monthly_trends[customer_type] = {
            'name': display_name,
            'data': list(monthly_data)
        }
    
    context = {
        'customer_groups': customer_groups,
        'overall_stats': overall_stats,
        'selected_group': selected_group,
        'time_period': time_period,
        'sort_by': sort_by,
        'detailed_customers': detailed_customers,
        'monthly_trends': monthly_trends,
        'customer_type_choices': Customer.TYPE_CHOICES,
        'start_date': start_date,
        'end_date': today,
    }
    
    return render(request, 'tracker/customer_groups.html', context)


@login_required
def orders_list(request: HttpRequest):
    from django.db.models import Q, Sum
    status = request.GET.get("status", "all")
    type_ = request.GET.get("type", "all")
    priority = request.GET.get("priority", "")
    date_range = request.GET.get("date_range", "")
    customer_id = request.GET.get("customer", "")

    qs = Order.objects.select_related("customer", "vehicle").order_by("-created_at")
    if status != "all" and status:
        qs = qs.filter(status=status)
    if type_ != "all" and type_:
        qs = qs.filter(type=type_)
    if priority:
        qs = qs.filter(priority=priority)
    if customer_id:
        qs = qs.filter(customer_id=customer_id)
    if date_range == 'today':
        qs = qs.filter(created_at__date=timezone.localdate())
    elif date_range == 'week':
        start = timezone.localdate() - timezone.timedelta(days=6)
        qs = qs.filter(created_at__date__gte=start)
    elif date_range == 'month':
        start = timezone.localdate().replace(day=1)
        qs = qs.filter(created_at__date__gte=start)

    # Stats (global snapshot)
    today = timezone.localdate()
    total_orders = Order.objects.count()
    pending_orders = Order.objects.filter(status__in=['created','assigned']).count()
    active_orders = Order.objects.filter(status__in=['in_progress']).count()
    completed_today = Order.objects.filter(status='completed', completed_at__date=today).count()
    urgent_orders = Order.objects.filter(priority='urgent').exclude(status='completed').count()
    revenue_today = 0

    paginator = Paginator(qs, 20)
    page = request.GET.get('page')
    orders = paginator.get_page(page)
    return render(request, "tracker/orders_list.html", {
        "orders": orders,
        "status": status,
        "type": type_,
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        "active_orders": active_orders,
        "completed_today": completed_today,
        "urgent_orders": urgent_orders,
        "revenue_today": revenue_today,
    })


@login_required
def order_start(request: HttpRequest):
    # Support GET ?customer=<id> to go straight into order form for that customer
    if request.method == 'GET':
        cust_id = request.GET.get('customer')
        if cust_id:
            c = get_object_or_404(Customer, pk=cust_id)
            form = OrderForm()
            form.fields['vehicle'].queryset = c.vehicles.all()
            return render(request, "tracker/order_create.html", {"customer": c, "form": form})
        form = OrderForm()
        try:
            form.fields['vehicle'].queryset = Vehicle.objects.none()
        except Exception:
            pass
        return render(request, "tracker/order_create.html", {"form": form})

    # Handle POST (AJAX or standard form submit)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        customer_id = request.POST.get('customer_id')
        if not customer_id:
            return JsonResponse({'success': False, 'message': 'Customer ID is required'})
        customer = get_object_or_404(Customer, id=customer_id)
        order_data = {
            'customer': customer,
            'type': request.POST.get('type'),
            'priority': request.POST.get('priority', 'medium'),
            'status': 'created',
            'description': request.POST.get('description', ''),
            'estimated_duration': request.POST.get('estimated_duration') or None,
            'item_name': (request.POST.get('item_name') or '').strip(),
            'brand': (request.POST.get('brand') or '').strip(),
            'quantity': None,
            'inquiry_type': (request.POST.get('inquiry_type') or '').strip(),
            'questions': request.POST.get('questions', ''),
            'contact_preference': (request.POST.get('contact_preference') or '').strip(),
            'follow_up_date': request.POST.get('follow_up_date') or None,
        }
        vehicle_id = request.POST.get('vehicle')
        if vehicle_id:
            vehicle = get_object_or_404(Vehicle, id=vehicle_id, customer=customer)
            order_data['vehicle'] = vehicle
        if order_data.get('type') == 'sales':
            name = (order_data.get('item_name') or '').strip()
            brand = (order_data.get('brand') or '').strip()
            try:
                qty = int(request.POST.get('quantity') or 0)
            except (TypeError, ValueError):
                qty = 0
            if not name or not brand or qty <= 0:
                return JsonResponse({'success': False, 'message': 'Item, brand and valid quantity are required', 'code': 'invalid'})
            from django.db.models import Q, Sum
            if (brand or '').lower() == 'unbranded':
                available = InventoryItem.objects.filter(name=name).filter(Q(brand__isnull=True) | Q(brand="")).aggregate(total=Sum('quantity')).get('total') or 0
            else:
                available = InventoryItem.objects.filter(name=name, brand=brand).aggregate(total=Sum('quantity')).get('total') or 0
            if available <= 0:
                return JsonResponse({'success': False, 'message': 'Item not found in inventory', 'code': 'not_found'})
            if available < qty:
                return JsonResponse({'success': False, 'message': f'Only {available} in stock for {name} ({brand})', 'code': 'insufficient_stock', 'available': available})
            order_data['quantity'] = qty
        order = Order.objects.create(**order_data)
        remaining = None
        if order.type == 'sales':
            from .utils import adjust_inventory
            qty_int = int(order.quantity or 0)
            ok, status, rem = adjust_inventory(order.item_name, order.brand, -qty_int)
            remaining = rem if ok else None
        return JsonResponse({'success': True, 'message': 'Order created successfully', 'order_id': order.id, 'remaining': remaining})

    # Standard form submit (non-AJAX)
    customer_id = request.POST.get('customer_id') or request.GET.get('customer')
    if not customer_id:
        messages.error(request, 'Customer is required to create an order')
        return render(request, "tracker/order_create.html")
    c = get_object_or_404(Customer, pk=customer_id)
    form = OrderForm(request.POST)
    form.fields['vehicle'].queryset = c.vehicles.all()
    if form.is_valid():
        o = form.save(commit=False)
        o.customer = c
        o.status = 'created'
        # Sales inventory validation
        if o.type == 'sales':
            name = (o.item_name or '').strip()
            brand = (o.brand or '').strip()
            qty = int(o.quantity or 0)
            from django.db.models import Q, Sum
            if (brand or '').lower() == 'unbranded':
                available = InventoryItem.objects.filter(name=name).filter(Q(brand__isnull=True) | Q(brand="")).aggregate(total=Sum('quantity')).get('total') or 0
            else:
                available = InventoryItem.objects.filter(name=name, brand=brand).aggregate(total=Sum('quantity')).get('total') or 0
            if not name or not brand or qty <= 0:
                messages.error(request, 'Item, brand and valid quantity are required')
                return render(request, "tracker/order_create.html", {"customer": c, "form": form})
            if available < qty:
                messages.error(request, f'Only {available} in stock for {name} ({brand})')
                return render(request, "tracker/order_create.html", {"customer": c, "form": form})
        o.save()
        if o.type == 'sales':
            from .utils import adjust_inventory
            qty_int = int(o.quantity or 0)
            ok, status, remaining = adjust_inventory(o.item_name, o.brand, -qty_int)
            if ok:
                messages.success(request, f"Order created. Remaining stock for {o.item_name} ({o.brand}): {remaining}")
            else:
                messages.warning(request, 'Order created, but inventory not adjusted')
        else:
            messages.success(request, 'Order created successfully')
        return redirect('tracker:order_detail', pk=o.id)
    messages.error(request, 'Please fix form errors and try again')
    return render(request, "tracker/order_create.html", {"customer": c, "form": form})


@login_required
def order_edit(request: HttpRequest, pk: int):
    """Edit an existing order"""
    order = get_object_or_404(Order, pk=pk)
    
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            order = form.save()
            messages.success(request, 'Order updated successfully.')
            return redirect('tracker:order_detail', pk=order.pk)
    else:
        form = OrderForm(instance=order)
    
    # Set the vehicle queryset to only include vehicles for this customer
    form.fields['vehicle'].queryset = order.customer.vehicles.all()
    
    return render(request, 'tracker/order_form.html', {
        'form': form,
        'order': order,
        'title': 'Edit Order',
        'customer': order.customer
    })


@login_required
def order_delete(request: HttpRequest, pk: int):
    """Delete an order"""
    order = get_object_or_404(Order, pk=pk)
    customer = order.customer
    
    if request.method == 'POST':
        try:
            # Log the deletion before actually deleting
            add_audit_log(
                request.user,
                'order_deleted',
                f'Deleted order {order.order_number} for customer {customer.full_name}',
                order_id=order.id,
                customer_id=customer.id
            )
        except Exception:
            pass
            
        order.delete()
        messages.success(request, f'Order {order.order_number} has been deleted.')
        
        # Redirect based on the 'next' parameter or to customer detail
        next_url = request.POST.get('next', None)
        if next_url:
            return redirect(next_url)
        return redirect('tracker:customer_detail', pk=customer.id)
    
    # If not a POST request, redirect to order detail
    return redirect('tracker:order_detail', pk=order.id)


@login_required
def order_detail(request: HttpRequest, pk: int):
    o = get_object_or_404(Order, pk=pk)
    return render(request, "tracker/order_detail.html", {"order": o})


@login_required
def update_order_status(request: HttpRequest, pk: int):
    o = get_object_or_404(Order, pk=pk)
    status = request.POST.get("status")
    now = timezone.now()
    if status in dict(Order.STATUS_CHOICES):
        o.status = status
        if status == "assigned":
            o.assigned_at = now
        elif status == "in_progress":
            o.started_at = now
        elif status == "completed":
            o.completed_at = now
            if o.started_at:
                o.actual_duration = int((now - o.started_at).total_seconds() // 60)
            c = o.customer
            c.total_spent = c.total_spent + 0  # integrate billing later
            c.last_visit = now
            c.current_status = "completed"
            c.save()
        elif status == "cancelled":
            o.cancelled_at = now
            # Restock on cancellation for sales orders
            if o.type == 'sales' and (o.quantity or 0) > 0 and o.item_name and o.brand:
                from .utils import adjust_inventory
                adjust_inventory(o.item_name, o.brand, (o.quantity or 0))
        o.save()
        try:
            add_audit_log(request.user, 'order_status_update', f"Order {o.order_number}: {o.status}")
        except Exception:
            pass
        messages.success(request, f"Order status updated to {status.replace('_',' ').title()}")
    else:
        messages.error(request, "Invalid status")
    return redirect("tracker:order_detail", pk=o.id)


@login_required
def analytics(request: HttpRequest):
    from datetime import timedelta
    period = request.GET.get('period', 'monthly')

    today = timezone.localdate()
    if period == 'daily':
        start_date = today
        end_date = today
        labels = [f"{i:02d}:00" for i in range(24)]
    elif period == 'weekly':
        start_date = today - timedelta(days=6)
        end_date = today
        labels = [(start_date + timedelta(days=i)).strftime('%a') for i in range(7)]
    elif period == 'yearly':
        start_date = today.replace(month=1, day=1)
        end_date = today
        labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    else:  # monthly
        start_date = today - timedelta(days=29)
        end_date = today
        labels = [(start_date + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(30)]

    qs = Order.objects.filter(created_at__date__range=[start_date, end_date])
    status_counts = {row['status']: row['c'] for row in qs.values('status').annotate(c=Count('id'))}
    type_counts = {row['type']: row['c'] for row in qs.values('type').annotate(c=Count('id'))}
    priority_counts = {row['priority']: row['c'] for row in qs.values('priority').annotate(c=Count('id'))}

    # Trend by selected period
    if period == 'daily':
        from django.db.models.functions import ExtractHour
        trend_map = {int(row['h'] or 0): row['c'] for row in qs.annotate(h=ExtractHour('created_at')).values('h').annotate(c=Count('id'))}
        trend_values = [trend_map.get(h, 0) for h in range(24)]
        trend_labels = labels
    elif period == 'weekly':
        by_date = {row['day']: row['c'] for row in qs.annotate(day=TruncDate('created_at')).values('day').annotate(c=Count('id'))}
        trend_values = []
        for i in range(7):
            d = start_date + timezone.timedelta(days=i)
            trend_values.append(by_date.get(d, 0))
        trend_labels = labels
    elif period == 'yearly':
        from django.db.models.functions import ExtractMonth
        by_month = {int(row['m']): row['c'] for row in qs.annotate(m=ExtractMonth('created_at')).values('m').annotate(c=Count('id'))}
        trend_values = [by_month.get(i, 0) for i in range(1, 13)]
        trend_labels = labels
    else:  # monthly
        by_date = {row['day']: row['c'] for row in qs.annotate(day=TruncDate('created_at')).values('day').annotate(c=Count('id'))}
        trend_values = []
        for i in range(30):
            d = start_date + timezone.timedelta(days=i)
            trend_values.append(by_date.get(d, 0))
        trend_labels = labels

    charts = {
        'status': {
            'labels': ['Created','Assigned','In Progress','Completed','Cancelled'],
            'values': [
                status_counts.get('created',0),
                status_counts.get('assigned',0),
                status_counts.get('in_progress',0),
                status_counts.get('completed',0),
                status_counts.get('cancelled',0),
            ]
        },
        'type': {
            'labels': ['Service','Sales','Consultation'],
            'values': [
                type_counts.get('service',0),
                type_counts.get('sales',0),
                type_counts.get('consultation',0),
            ]
        },
        'priority': {
            'labels': ['Low','Medium','High','Urgent'],
            'values': [
                priority_counts.get('low',0),
                priority_counts.get('medium',0),
                priority_counts.get('high',0),
                priority_counts.get('urgent',0),
            ]
        },
        'trend': { 'labels': trend_labels, 'values': trend_values },
    }

    totals = {
        'total_orders': qs.count(),
        'completed': qs.filter(status='completed').count(),
        'in_progress': qs.filter(status__in=['created','assigned','in_progress']).count(),
        'customers': Customer.objects.filter(registration_date__date__range=[start_date, end_date]).count(),
    }

    return render(request, 'tracker/analytics.html', {
        'charts_json': json.dumps(charts),
        'totals': totals,
        'period': period,
        'export_from': start_date.isoformat(),
        'export_to': end_date.isoformat(),
    })


@login_required
def reports(request: HttpRequest):
    f_from = request.GET.get("from")
    f_to = request.GET.get("to")
    f_type = request.GET.get("type", "all")
    qs = Order.objects.select_related("customer").order_by("-created_at")
    if f_from:
        try:
            qs = qs.filter(created_at__date__gte=f_from)
        except Exception:
            pass
    if f_to:
        try:
            qs = qs.filter(created_at__date__lte=f_to)
        except Exception:
            pass
    if f_type and f_type != "all":
        qs = qs.filter(type=f_type)

    total = qs.count()
    by_status = dict(qs.values_list("status").annotate(c=Count("id")))
    stats = {
        "total": total,
        "completed": by_status.get("completed", 0),
        "in_progress": by_status.get("in_progress", 0),
        "cancelled": by_status.get("cancelled", 0),
    }
    orders = list(qs[:300])
    return render(
        request,
        "tracker/reports.html",
        {"orders": orders, "stats": stats, "filters": {"from": f_from, "to": f_to, "type": f_type}},
    )

@login_required
def reports_export(request: HttpRequest):
    # Same filters as reports
    f_from = request.GET.get("from")
    f_to = request.GET.get("to")
    f_type = request.GET.get("type", "all")
    qs = Order.objects.select_related("customer").order_by("-created_at")
    if f_from:
        try:
            qs = qs.filter(created_at__date__gte=f_from)
        except Exception:
            pass
    if f_to:
        try:
            qs = qs.filter(created_at__date__lte=f_to)
        except Exception:
            pass
    if f_type and f_type != "all":
        qs = qs.filter(type=f_type)

    # Build CSV
    import csv
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="orders_report.csv"'
    writer = csv.writer(response)
    writer.writerow(["Order", "Customer", "Type", "Status", "Priority", "Created At"])
    for o in qs.iterator():
        writer.writerow([o.order_number, o.customer.full_name, o.type, o.status, o.priority, o.created_at.isoformat()])
    return response

@login_required
def customers_export(request: HttpRequest):
    q = request.GET.get('q','').strip()
    qs = Customer.objects.all().order_by('-registration_date')
    if q:
        qs = qs.filter(full_name__icontains=q)
    import csv
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="customers.csv"'
    writer = csv.writer(response)
    writer.writerow(['Code','Name','Phone','Type','Visits','Last Visit'])
    for c in qs.iterator():
        writer.writerow([c.code, c.full_name, c.phone, c.customer_type, c.total_visits, c.last_visit.isoformat() if c.last_visit else '' ])
    return response

@login_required
def orders_export(request: HttpRequest):
    status = request.GET.get('status','all')
    type_ = request.GET.get('type','all')
    qs = Order.objects.select_related('customer').order_by('-created_at')
    if status != 'all':
        qs = qs.filter(status=status)
    if type_ != 'all':
        qs = qs.filter(type=type_)
    import csv
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    writer = csv.writer(response)
    writer.writerow(["Order","Customer","Type","Status","Priority","Created At"])
    for o in qs.iterator():
        writer.writerow([o.order_number, o.customer.full_name, o.type, o.status, o.priority, o.created_at.isoformat()])
    return response

@login_required
def customer_groups_export(request: HttpRequest):
    """Export filtered customer group data to CSV"""
    from datetime import timedelta
    selected_group = request.GET.get('group', '')
    time_period = request.GET.get('period', '6months')
    today = timezone.now().date()
    if time_period == '1month':
        start_date = today - timedelta(days=30)
    elif time_period == '3months':
        start_date = today - timedelta(days=90)
    elif time_period == '6months':
        start_date = today - timedelta(days=180)
    elif time_period == '1year':
        start_date = today - timedelta(days=365)
    else:
        start_date = today - timedelta(days=180)

    qs = Customer.objects.annotate(
        recent_orders_count=Count('orders', filter=Q(orders__created_at__date__gte=start_date)),
        last_order_date=Max('orders__created_at'),
        service_orders=Count('orders', filter=Q(orders__type='service', orders__created_at__date__gte=start_date)),
        sales_orders=Count('orders', filter=Q(orders__type='sales', orders__created_at__date__gte=start_date)),
        consultation_orders=Count('orders', filter=Q(orders__type='consultation', orders__created_at__date__gte=start_date)),
        completed_orders=Count('orders', filter=Q(orders__status='completed', orders__created_at__date__gte=start_date)),
        vehicles_count=Count('vehicles', distinct=True),
    )
    if selected_group and selected_group in dict(Customer.TYPE_CHOICES):
        qs = qs.filter(customer_type=selected_group)
    import csv
    resp = HttpResponse(content_type='text/csv')
    resp['Content-Disposition'] = 'attachment; filename="customer_group.csv"'
    w = csv.writer(resp)
    w.writerow(['Code','Name','Phone','Type','Visits','Total Spent','Orders (period)','Service','Sales','Consultation','Completed (period)','Vehicles','Last Order'])
    for c in qs.iterator():
        w.writerow([
            c.code,
            c.full_name,
            c.phone,
            c.customer_type,
            c.total_visits,
            c.total_spent,
            c.recent_orders_count,
            c.service_orders,
            c.sales_orders,
            c.consultation_orders,
            c.completed_orders,
            c.vehicles_count,
            c.last_order_date.isoformat() if c.last_order_date else '',
        ])
    return resp

@login_required
def profile(request: HttpRequest):
    """Update current user's profile (name and photo)."""
    user = request.user
    initial = {
        'first_name': user.first_name,
        'last_name': user.last_name,
    }
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save(user)
            messages.success(request, 'Profile updated')
            return redirect('tracker:profile')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = ProfileForm(initial=initial)
    try:
        profile_obj = user.profile
    except Profile.DoesNotExist:
        profile_obj = None
    return render(request, 'tracker/profile.html', {'form': form, 'profile': profile_obj})

@login_required
def api_recent_orders(request: HttpRequest):
    recents = Order.objects.select_related("customer", "vehicle").exclude(status="completed").order_by("-created_at")[:10]
    data = [
        {
            "order_number": r.order_number,
            "status": r.status,
            "type": r.type,
            "priority": r.priority,
            "customer": r.customer.full_name,
            "vehicle": r.vehicle.plate_number if r.vehicle else None,
            "created_at": r.created_at.isoformat(),
        }
        for r in recents
    ]
    return JsonResponse({"orders": data})

@login_required
def api_inventory_items(request: HttpRequest):
    from django.db.models import Sum
    cache_key = "api_inv_items_v1"
    data = cache.get(cache_key)
    if not data:
        rows = (
            InventoryItem.objects.values("name")
            .annotate(total=Sum("quantity"))
            .order_by("name")
        )
        items = [{"name": r["name"], "total_quantity": r["total"] or 0} for r in rows]
        data = {"items": items}
        cache.set(cache_key, data, 120)
    return JsonResponse(data)

@login_required
def api_inventory_brands(request: HttpRequest):
    from django.db.models import Sum, Min
    name = request.GET.get("name", "").strip()
    if not name:
        return JsonResponse({"brands": []})
    cache_key = f"api_inv_brands_{name}"
    data = cache.get(cache_key)
    if not data:
        # Aggregate by brand for this item
        rows = (
            InventoryItem.objects.filter(name=name)
            .values("brand")
            .annotate(quantity=Sum("quantity"), min_price=Min("price"))
            .order_by("brand")
        )
        non_empty = []
        unbranded_qty = 0
        unbranded_price = None
        for r in rows:
            b = (r["brand"] or "").strip()
            q = r["quantity"] or 0
            p = r["min_price"]
            if b:
                non_empty.append({"brand": b, "quantity": q, "price": str(p) if p is not None else ""})
            else:
                unbranded_qty += q
                if p is not None:
                    unbranded_price = p if unbranded_price is None else min(unbranded_price, p)
        brands = non_empty
        # Always include an aggregated Unbranded option when quantity exists
        if unbranded_qty > 0:
            brands.append({
                "brand": "Unbranded",
                "quantity": unbranded_qty,
                "price": str(unbranded_price) if unbranded_price is not None else ""
            })
        data = {"brands": brands}
        cache.set(cache_key, data, 120)
    return JsonResponse(data)

@login_required
def api_inventory_stock(request: HttpRequest):
    """API endpoint to check inventory stock for an item"""
    name = request.GET.get('name', '').strip()
    brand = request.GET.get('brand', '').strip()
    
    if not name or not brand:
        return JsonResponse({'error': 'Both name and brand parameters are required'}, status=400)
    
    try:
        item = InventoryItem.objects.get(name__iexact=name, brand__iexact=brand)
        return JsonResponse({
            'name': item.name,
            'brand': item.brand,
            'quantity': item.quantity,
            'unit': item.unit,
            'unit_price': item.unit_price
        })
    except InventoryItem.DoesNotExist:
        return JsonResponse({'error': 'Item not found'}, status=404)

@login_required
def vehicle_add(request: HttpRequest, customer_id: int):
    """Add a new vehicle for a customer"""
    customer = get_object_or_404(Customer, pk=customer_id)
    
    if request.method == 'POST':
        form = VehicleForm(request.POST)
        if form.is_valid():
            vehicle = form.save(commit=False)
            vehicle.customer = customer
            vehicle.save()
            messages.success(request, 'Vehicle added successfully.')
            return redirect('tracker:customer_detail', pk=customer_id)
    else:
        form = VehicleForm()
    
    return render(request, 'tracker/vehicle_form.html', {
        'form': form,
        'customer': customer,
        'title': 'Add Vehicle'
    })


@login_required
def customer_delete(request: HttpRequest, pk: int):
    """Delete a customer and all associated data"""
    customer = get_object_or_404(Customer, pk=pk)
    
    if request.method == 'POST':
        # Log the deletion before actually deleting
        try:
            add_audit_log(
                request.user,
                'customer_deleted',
                f'Deleted customer {customer.full_name} (ID: {customer.id})',
                customer_id=customer.id
            )
        except Exception:
            pass
        
        # Delete the customer (this will cascade to related objects)
        customer.delete()
        messages.success(request, f'Customer {customer.full_name} has been deleted.')
        return redirect('tracker:customers_list')
    
    # If not a POST request, redirect to customer detail
    return redirect('tracker:customer_detail', pk=customer.id)


@login_required
def vehicle_edit(request: HttpRequest, pk: int):
    """Edit an existing vehicle"""
    vehicle = get_object_or_404(Vehicle, pk=pk)
    
    if request.method == 'POST':
        form = VehicleForm(request.POST, instance=vehicle)
        if form.is_valid():
            form.save()
            messages.success(request, 'Vehicle updated successfully.')
            return redirect('tracker:customer_detail', pk=vehicle.customer_id)
    else:
        form = VehicleForm(instance=vehicle)
    
    return render(request, 'tracker/vehicle_form.html', {
        'form': form,
        'customer': vehicle.customer,
        'title': 'Edit Vehicle'
    })


@login_required
def vehicle_delete(request: HttpRequest, pk: int):
    """Delete a vehicle"""
    vehicle = get_object_or_404(Vehicle, pk=pk)
    customer_id = vehicle.customer_id
    
    if request.method == 'POST':
        vehicle.delete()
        messages.success(request, 'Vehicle deleted successfully.')
        return redirect('tracker:customer_detail', pk=customer_id)
    
    return render(request, 'tracker/confirm_delete.html', {
        'object': vehicle,
        'cancel_url': reverse('tracker:customer_detail', kwargs={'pk': customer_id}),
        'item_type': 'vehicle'
    })


@login_required
def api_customer_vehicles(request: HttpRequest, customer_id: int):
    """API endpoint to get vehicles for a specific customer"""
    try:
        customer = Customer.objects.get(pk=customer_id)
        vehicles = [{
            'id': v.id,
            'make': v.make or '',
            'model': v.model or '',
            'year': getattr(v, 'year', None),
            'license_plate': v.plate_number or '',
            'vin': getattr(v, 'vin', '') or ''
        } for v in customer.vehicles.all()]

        return JsonResponse({
            'success': True,
            'vehicles': vehicles
        })
    except Customer.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Customer not found'}, status=404)

@login_required
def api_notifications_summary(request: HttpRequest):
    """Return notification summary for header dropdown: today's visitors, low stock, overdue orders"""
    from datetime import timedelta
    stock_threshold = int(request.GET.get('stock_threshold', 5) or 5)
    overdue_hours = int(request.GET.get('overdue_hours', 24) or 24)

    today = timezone.localdate()
    now = timezone.now()
    cutoff = now - timedelta(hours=overdue_hours)

    # Today's visitors (arrival_time today)
    todays_qs = Customer.objects.filter(arrival_time__date=today).order_by('-arrival_time')
    todays_count = todays_qs.count()
    todays = [{
        'id': c.id,
        'name': c.full_name,
        'code': c.code,
        'time': c.arrival_time.isoformat() if c.arrival_time else None
    } for c in todays_qs[:8]]

    # Low stock items
    low_qs = InventoryItem.objects.filter(quantity__lte=stock_threshold).order_by('quantity', 'name')
    low_count = low_qs.count()
    low_stock = [{
        'id': i.id,
        'name': i.name,
        'brand': i.brand or 'Unbranded',
        'quantity': i.quantity
    } for i in low_qs[:8]]

    # Overdue orders (not completed, older than cutoff)
    overdue_qs = Order.objects.filter(status__in=['created','assigned','in_progress'], created_at__lt=cutoff).select_related('customer').order_by('created_at')
    overdue_count = overdue_qs.count()
    def age_minutes(dt):
        return int((now - dt).total_seconds() // 60) if dt else None
    overdue = [{
        'id': o.id,
        'order_number': o.order_number,
        'customer': o.customer.full_name,
        'status': o.status,
        'age_minutes': age_minutes(o.created_at)
    } for o in overdue_qs[:8]]

    total_new = todays_count + low_count + overdue_count
    return JsonResponse({
        'success': True,
        'counts': {
            'today_visitors': todays_count,
            'low_stock': low_count,
            'overdue_orders': overdue_count,
            'total': total_new,
        },
        'items': {
            'today_visitors': todays,
            'low_stock': low_stock,
            'overdue_orders': overdue,
        }
    })

# Permissions
is_manager = user_passes_test(lambda u: u.is_authenticated and (u.is_superuser or u.groups.filter(name='manager').exists()))

@login_required
@is_manager
def inventory_list(request: HttpRequest):
    q = request.GET.get('q','').strip()
    qs = InventoryItem.objects.all().order_by('-created_at')
    if q:
        qs = qs.filter(name__icontains=q)
    paginator = Paginator(qs, 20)
    page = request.GET.get('page')
    items = paginator.get_page(page)
    return render(request, 'tracker/inventory_list.html', { 'items': items, 'q': q })

@login_required
@is_manager
def inventory_create(request: HttpRequest):
    from .forms import InventoryItemForm
    if request.method == 'POST':
        form = InventoryItemForm(request.POST)
        if form.is_valid():
            item = form.save()
            from .utils import clear_inventory_cache
            clear_inventory_cache(item.name, item.brand)
            try:
                add_audit_log(request.user, 'inventory_create', f"Item '{item.name}' ({item.brand or 'Unbranded'}) qty={item.quantity}")
            except Exception:
                pass
            messages.success(request, 'Inventory item created')
            return redirect('tracker:inventory_list')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = InventoryItemForm()
    return render(request, 'tracker/inventory_form.html', { 'form': form, 'mode': 'create' })

@login_required
@is_manager
def inventory_edit(request: HttpRequest, pk: int):
    from .forms import InventoryItemForm
    item = get_object_or_404(InventoryItem, pk=pk)
    if request.method == 'POST':
        form = InventoryItemForm(request.POST, instance=item)
        if form.is_valid():
            item = form.save()
            from .utils import clear_inventory_cache
            clear_inventory_cache(item.name, item.brand)
            try:
                add_audit_log(request.user, 'inventory_update', f"Item '{item.name}' ({item.brand or 'Unbranded'}) now qty={item.quantity}")
            except Exception:
                pass
            messages.success(request, 'Inventory item updated')
            return redirect('tracker:inventory_list')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = InventoryItemForm(instance=item)
    return render(request, 'tracker/inventory_form.html', { 'form': form, 'mode': 'edit', 'item': item })

@login_required
@is_manager
def inventory_delete(request: HttpRequest, pk: int):
    item = get_object_or_404(InventoryItem, pk=pk)
    if request.method == 'POST':
        from .utils import clear_inventory_cache
        name, brand = item.name, item.brand
        item.delete()
        clear_inventory_cache(name, brand)
        try:
            add_audit_log(request.user, 'inventory_delete', f"Deleted item '{name}' ({brand or 'Unbranded'})")
        except Exception:
            pass
        messages.success(request, 'Inventory item deleted')
        return redirect('tracker:inventory_list')
    return render(request, 'tracker/inventory_delete.html', { 'item': item })

# Admin-only: Organization Management
@login_required
@user_passes_test(lambda u: u.is_superuser)
def organization_management(request: HttpRequest):
    org_types = ['government', 'ngo', 'company']
    q = request.GET.get('q','').strip()
    qs = Customer.objects.filter(customer_type__in=org_types).order_by('-registration_date')
    if q:
        qs = qs.filter(Q(full_name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q) | Q(organization_name__icontains=q) | Q(code__icontains=q))
    paginator = Paginator(qs, 20)
    page = request.GET.get('page')
    customers = paginator.get_page(page)
    type_counts = Customer.objects.filter(customer_type__in=org_types).values('customer_type').annotate(c=Count('id'))
    counts = {row['customer_type']: row['c'] for row in type_counts}
    total_org = sum(counts.values()) if counts else 0
    return render(request, 'tracker/organization.html', { 'customers': customers, 'q': q, 'counts': counts, 'total_org': total_org })

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def users_list(request: HttpRequest):
    q = request.GET.get('q','').strip()
    qs = User.objects.all().order_by('-date_joined')
    if q:
        qs = qs.filter(username__icontains=q)
    return render(request, 'tracker/users_list.html', { 'users': qs[:100], 'q': q })

@login_required
@user_passes_test(lambda u: u.is_superuser)
def user_create(request: HttpRequest):
    from .forms import AdminUserCreateForm
    if request.method == 'POST':
        form = AdminUserCreateForm(request.POST)
        if form.is_valid():
            new_user = form.save()
            add_audit_log(request.user, 'user_create', f'Created user {new_user.username}')
            messages.success(request, 'User created')
            return redirect('tracker:users_list')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = AdminUserCreateForm()
    return render(request, 'tracker/user_create.html', { 'form': form })

@login_required
@user_passes_test(lambda u: u.is_superuser)
def user_edit(request: HttpRequest, pk: int):
    from .forms import AdminUserForm
    u = get_object_or_404(User, pk=pk)
    if request.method == 'POST':
        form = AdminUserForm(request.POST, instance=u)
        if form.is_valid():
            updated_user = form.save()
            add_audit_log(request.user, 'user_update', f'Updated user {updated_user.username}')
            messages.success(request, 'User updated')
            return redirect('tracker:users_list')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = AdminUserForm(instance=u)
    return render(request, 'tracker/user_edit.html', { 'form': form, 'user_obj': u })


@login_required
def customer_edit(request: HttpRequest, pk: int):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        form = CustomerEditForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            try:
                add_audit_log(request.user, 'customer_update', f"Updated customer {customer.full_name} ({customer.code})")
            except Exception:
                pass
            messages.success(request, 'Customer updated successfully')
            return redirect('tracker:customer_detail', pk=customer.id)
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = CustomerEditForm(instance=customer)
    return render(request, 'tracker/customer_edit.html', { 'form': form, 'customer': customer })


@login_required
def customers_quick_create(request: HttpRequest):
    """Quick customer creation for order form"""
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        try:
            full_name = request.POST.get('full_name', '').strip()
            phone = request.POST.get('phone', '').strip()
            email = request.POST.get('email', '').strip()
            customer_type = request.POST.get('customer_type', 'personal')

            if not full_name or not phone:
                return JsonResponse({'success': False, 'message': 'Name and phone are required'})

            # Check if customer with this phone already exists
            if Customer.objects.filter(phone=phone).exists():
                return JsonResponse({'success': False, 'message': 'Customer with this phone number already exists'})

            # Create customer
            customer = Customer.objects.create(
                full_name=full_name,
                phone=phone,
                email=email if email else None,
                customer_type=customer_type
            )

            try:
                add_audit_log(request.user, 'customer_create', f"Created customer {customer.full_name} ({customer.code})")
            except Exception:
                pass

            return JsonResponse({
                'success': True,
                'message': 'Customer created successfully',
                'customer': {
                    'id': customer.id,
                    'name': customer.full_name,
                    'phone': customer.phone,
                    'email': customer.email or '',
                    'code': customer.code,
                    'type': customer.customer_type
                }
            })

        except Exception as e:
            return JsonResponse({'success': False, 'message': f'Error creating customer: {str(e)}'})

    return JsonResponse({'success': False, 'message': 'Invalid request'})


@login_required
def inquiries(request: HttpRequest):
    """View and manage customer inquiries"""
    # Get filter parameters
    inquiry_type = request.GET.get('type', '')
    status = request.GET.get('status', '')
    follow_up = request.GET.get('follow_up', '')

    # Base queryset for consultation orders (inquiries)
    queryset = Order.objects.filter(type='consultation').select_related('customer').order_by('-created_at')

    # Apply filters
    if inquiry_type:
        queryset = queryset.filter(inquiry_type=inquiry_type)

    if status:
        queryset = queryset.filter(status=status)

    if follow_up == 'required':
        queryset = queryset.filter(follow_up_date__isnull=False)
    elif follow_up == 'overdue':
        today = timezone.localdate()
        queryset = queryset.filter(
            follow_up_date__lte=today,
            status__in=['created', 'in_progress']
        )

    # Pagination
    paginator = Paginator(queryset, 12)  # Show 12 inquiries per page
    page = request.GET.get('page')
    inquiries = paginator.get_page(page)

    # Statistics
    stats = {
        'new': Order.objects.filter(type='consultation', status='created').count(),
        'in_progress': Order.objects.filter(type='consultation', status='in_progress').count(),
        'resolved': Order.objects.filter(type='consultation', status='completed').count(),
    }

    context = {
        'inquiries': inquiries,
        'stats': stats,
        'today': timezone.localdate(),
    }

    return render(request, 'tracker/inquiries.html', context)


@login_required
def inquiry_detail(request: HttpRequest, pk: int):
    """Get inquiry details for modal view"""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        try:
            inquiry = get_object_or_404(Order, pk=pk, type='consultation')

            data = {
                'id': inquiry.id,
                'customer': {
                    'name': inquiry.customer.full_name,
                    'phone': inquiry.customer.phone,
                    'email': inquiry.customer.email or '',
                },
                'inquiry_type': inquiry.inquiry_type or 'General',
                'contact_preference': inquiry.contact_preference or 'Phone',
                'questions': inquiry.questions or '',
                'status': inquiry.status,
                'status_display': inquiry.get_status_display(),
                'created_at': inquiry.created_at.isoformat(),
                'follow_up_date': inquiry.follow_up_date.isoformat() if inquiry.follow_up_date else None,
                'responses': [],  # In a real app, you'd have a related model for responses
            }

            return JsonResponse(data)

        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

    return JsonResponse({'error': 'Invalid request'}, status=400)


@login_required
def inquiry_respond(request: HttpRequest, pk: int):
    """Respond to a customer inquiry"""
    from .utils import send_sms
    inquiry = get_object_or_404(Order, pk=pk, type='consultation')

    if request.method == 'POST':
        response_text = request.POST.get('response', '').strip()
        follow_up_required = request.POST.get('follow_up_required') == 'on'
        follow_up_date = request.POST.get('follow_up_date')

        if not response_text:
            messages.error(request, 'Response message is required')
            return redirect('tracker:inquiries')

        # Append response into inquiry questions thread
        stamp = timezone.now().strftime('%Y-%m-%d %H:%M')
        trail = f"[{stamp}] Response: {response_text}"
        if inquiry.questions:
            inquiry.questions = (inquiry.questions or '') + "\n\n" + trail
        else:
            inquiry.questions = trail

        # Update follow-up date if required
        if follow_up_required and follow_up_date:
            try:
                inquiry.follow_up_date = follow_up_date
            except ValueError:
                pass

        # Mark as in progress if not already completed
        if inquiry.status == 'created':
            inquiry.status = 'in_progress'

        inquiry.save()
        try:
            add_audit_log(request.user, 'inquiry_respond', f"Responded to inquiry #{inquiry.id} for {inquiry.customer.full_name}")
        except Exception:
            pass

        # Send SMS to the customer's phone
        phone = inquiry.customer.phone
        sms_message = f"Hello {inquiry.customer.full_name}, regarding your inquiry ({inquiry.inquiry_type or 'General'}): {response_text} — Superdoll Support"
        ok, info = send_sms(phone, sms_message)
        if ok:
            messages.success(request, 'Response sent via SMS')
        else:
            messages.warning(request, f'Response saved, but SMS not sent: {info}')
        return redirect('tracker:inquiries')

    return redirect('tracker:inquiries')


@login_required
def update_inquiry_status(request: HttpRequest, pk: int):
    """Update inquiry status"""
    inquiry = get_object_or_404(Order, pk=pk, type='consultation')

    if request.method == 'POST':
        new_status = request.POST.get('status')

        if new_status in ['created', 'in_progress', 'completed']:
            old_status = inquiry.status
            inquiry.status = new_status

            if new_status == 'completed':
                inquiry.completed_at = timezone.now()

            inquiry.save()
            try:
                add_audit_log(request.user, 'inquiry_status_update', f"Inquiry #{inquiry.id}: {old_status} -> {new_status}")
            except Exception:
                pass

            status_display = {
                'created': 'New',
                'in_progress': 'In Progress',
                'completed': 'Resolved'
            }

            messages.success(request, f'Inquiry status updated to {status_display.get(new_status, new_status)}')
        else:
            messages.error(request, 'Invalid status')

    return redirect('tracker:inquiries')


@login_required
def reports_advanced(request: HttpRequest):
    """Advanced reports with period and type filters"""
    from datetime import timedelta, datetime, time as dt_time

    period = request.GET.get('period', 'monthly')
    report_type = request.GET.get('type', 'overview')

    # Calculate date range based on period
    today = timezone.localdate()
    if period == 'daily':
        start_date = today
        end_date = today
        date_format = '%H:%M'
        labels = [f"{i:02d}:00" for i in range(24)]
    elif period == 'weekly':
        start_date = today - timedelta(days=6)
        end_date = today
        date_format = '%a'
        labels = [(start_date + timedelta(days=i)).strftime('%a') for i in range(7)]
    elif period == 'yearly':
        start_date = today.replace(month=1, day=1)
        end_date = today
        date_format = '%b'
        labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    else:  # monthly
        start_date = today - timedelta(days=29)
        end_date = today
        date_format = '%d'
        labels = [(start_date + timedelta(days=i)).strftime('%d') for i in range(30)]

    # Compute timezone-aware datetime range [start_dt, end_dt)
    tz = timezone.get_current_timezone()
    start_dt = timezone.make_aware(datetime.combine(start_date, dt_time.min), tz)
    end_dt = timezone.make_aware(datetime.combine(end_date + timedelta(days=1), dt_time.min), tz)

    # Reuse filtered querysets for consistency
    qs = Order.objects.filter(created_at__gte=start_dt, created_at__lt=end_dt)
    cqs = Customer.objects.filter(registration_date__gte=start_dt, registration_date__lt=end_dt)

    # Base statistics
    total_orders = qs.count()
    completed_orders = qs.filter(status='completed').count()
    pending_orders = qs.filter(status__in=['created', 'assigned', 'in_progress']).count()
    total_customers = cqs.count()

    completion_rate = int((completed_orders * 100) / total_orders) if total_orders > 0 else 0

    # Average duration
    avg_duration_qs = qs.filter(
        actual_duration__isnull=False
    ).aggregate(avg_duration=Avg('actual_duration'))
    avg_duration = int(avg_duration_qs['avg_duration'] or 0)

    stats = {
        'total_orders': total_orders,
        'completed_orders': completed_orders,
        'pending_orders': pending_orders,
        'total_customers': total_customers,
        'completion_rate': completion_rate,
        'avg_duration': avg_duration,
        'new_customers': total_customers,
        'avg_service_time': avg_duration,
        # Order type breakdown
        'service_orders': qs.filter(type='service').count(),
        'sales_orders': qs.filter(type='sales').count(),
        'consultation_orders': qs.filter(type='consultation').count(),
    }

    # Calculate percentages
    if total_orders > 0:
        stats['service_percentage'] = int((stats['service_orders'] * 100) / total_orders)
        stats['sales_percentage'] = int((stats['sales_orders'] * 100) / total_orders)
        stats['consultation_percentage'] = int((stats['consultation_orders'] * 100) / total_orders)
    else:
        stats['service_percentage'] = stats['sales_percentage'] = stats['consultation_percentage'] = 0

    # Real trend data per selected period
    qs = Order.objects.filter(created_at__gte=start_dt, created_at__lt=end_dt)
    if period == 'daily':
        from django.db.models.functions import ExtractHour
        trend_map = {int(r['h'] or 0): r['c'] for r in qs.annotate(h=ExtractHour('created_at')).values('h').annotate(c=Count('id'))}
        trend_values = [trend_map.get(h, 0) for h in range(24)]
    elif period == 'weekly':
        by_date = {r['day']: r['c'] for r in qs.annotate(day=TruncDate('created_at')).values('day').annotate(c=Count('id'))}
        trend_values = [(by_date.get(start_date + timedelta(days=i), 0)) for i in range(7)]
    elif period == 'yearly':
        from django.db.models.functions import ExtractMonth
        by_month = {int(r['m']): r['c'] for r in qs.annotate(m=ExtractMonth('created_at')).values('m').annotate(c=Count('id'))}
        trend_values = [by_month.get(i, 0) for i in range(1, 13)]
    else:  # monthly
        by_date = {r['day']: r['c'] for r in qs.annotate(day=TruncDate('created_at')).values('day').annotate(c=Count('id'))}
        trend_values = [(by_date.get(start_date + timedelta(days=i), 0)) for i in range(30)]

    chart_data = {
        'trend': { 'labels': labels, 'values': trend_values },
        'status': {
            'labels': ['Created', 'Assigned', 'In Progress', 'Completed', 'Cancelled'],
            'values': [
                qs.filter(status='created').count(),
                qs.filter(status='assigned').count(),
                qs.filter(status='in_progress').count(),
                qs.filter(status='completed').count(),
                qs.filter(status='cancelled').count(),
            ]
        },
        'orders': {
            'labels': ['Service', 'Sales', 'Consultation'],
            'values': [stats['service_orders'], stats['sales_orders'], stats['consultation_orders']]
        },
        'types': {
            'labels': ['Personal', 'Company', 'Government', 'NGO', 'Bodaboda'],
            'values': [
                cqs.filter(customer_type='personal').count(),
                cqs.filter(customer_type='company').count(),
                cqs.filter(customer_type='government').count(),
                cqs.filter(customer_type='ngo').count(),
                cqs.filter(customer_type='bodaboda').count(),
            ]
        }
    }

    # Get data items based on report type
    if report_type == 'customers':
        data_items = cqs.order_by('-registration_date')[:20]
    elif report_type == 'inquiries':
        data_items = qs.filter(type='consultation').select_related('customer').order_by('-created_at')[:20]
    else:
        data_items = qs.select_related('customer').order_by('-created_at')[:20]

    context = {
        'period': period,
        'report_type': report_type,
        'stats': stats,
        'chart_data': json.dumps(chart_data),
        'data_items': data_items,
        'start_date': start_date.isoformat(),
        'end_date': end_date.isoformat(),
    }

    return render(request, 'tracker/reports_advanced.html', context)

# ---------------------------
# System settings and admin
# ---------------------------
@login_required
@user_passes_test(lambda u: u.is_superuser)
def system_settings(request: HttpRequest):
    def defaults():
        return {
            'company_name': '',
            'default_priority': 'medium',
            'enable_unbranded_alias': True,
            'allow_order_without_vehicle': True,
            'sms_provider': 'none',
        }
    data = cache.get('system_settings', None) or defaults()
    if request.method == 'POST':
        form = SystemSettingsForm(request.POST)
        if form.is_valid():
            new_data = {**defaults(), **form.cleaned_data}
            changes = []
            for k, old_val in (data or {}).items():
                new_val = new_data.get(k)
                if new_val != old_val:
                    changes.append(f"{k}: '{old_val}' -> '{new_val}'")
            cache.set('system_settings', new_data, None)
            add_audit_log(request.user, 'system_settings_update', '; '.join(changes) if changes else 'No changes')
            messages.success(request, 'Settings updated')
            return redirect('tracker:system_settings')
        else:
            messages.error(request, 'Please correct errors and try again')
    else:
        form = SystemSettingsForm(initial=data)
    return render(request, 'tracker/system_settings.html', {'form': form, 'settings': data})

@login_required
@user_passes_test(lambda u: u.is_superuser)
def audit_logs(request: HttpRequest):
    if request.method == 'POST' and request.POST.get('action') == 'clear':
        clear_audit_logs()
        add_audit_log(request.user, 'audit_logs_cleared', 'Cleared all audit logs')
        messages.success(request, 'Audit logs cleared')
        return redirect('tracker:audit_logs')
    logs = get_audit_logs()
    return render(request, 'tracker/audit_logs.html', {'logs': logs})

@login_required
@user_passes_test(lambda u: u.is_superuser)
def backup_restore(request: HttpRequest):
    if request.GET.get('download'):
        import json
        payload = {
            'system_settings': cache.get('system_settings', {}),
        }
        add_audit_log(request.user, 'backup_download', 'Downloaded system settings backup')
        resp = HttpResponse(json.dumps(payload, indent=2), content_type='application/json')
        resp['Content-Disposition'] = 'attachment; filename="backup.json"'
        return resp
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'reset_settings':
            cache.delete('system_settings')
            add_audit_log(request.user, 'settings_reset', 'Reset system settings to defaults')
            messages.success(request, 'System settings have been reset to defaults')
            return redirect('tracker:backup_restore')
        if action == 'restore_settings' and request.FILES.get('file'):
            f = request.FILES['file']
            try:
                data = json.load(f)
                settings_data = data.get('system_settings') or {}
                if isinstance(settings_data, dict):
                    cache.set('system_settings', settings_data, None)
                    add_audit_log(request.user, 'settings_restored', 'Restored system settings from uploaded backup')
                    messages.success(request, 'Settings restored from backup')
                else:
                    messages.error(request, 'Invalid backup file format')
            except Exception as e:
                messages.error(request, f'Failed to restore: {e}')
            return redirect('tracker:backup_restore')
    return render(request, 'tracker/backup_restore.html')


# ---------------------------
# Analytics Sub-Pages
# ---------------------------
@login_required
def analytics_customer(request: HttpRequest):
    """Customer analytics page"""
    return render(request, 'tracker/analytics_customer.html', {
        'page_title': 'Customer Analytics',
        'today': timezone.localdate(),
    })

@login_required
def analytics_service(request: HttpRequest):
    """Service analytics page"""
    return render(request, 'tracker/analytics_service.html', {
        'page_title': 'Service Analytics',
        'today': timezone.localdate(),
    })

@login_required
def analytics_revenue(request: HttpRequest):
    """Revenue analytics page"""
    return render(request, 'tracker/analytics_revenue.html', {
        'page_title': 'Revenue Analytics',
        'today': timezone.localdate(),
    })

@login_required
def analytics_performance(request: HttpRequest):
    """Performance metrics page"""
    return render(request, 'tracker/analytics_performance.html', {
        'page_title': 'Performance Metrics',
        'today': timezone.localdate(),
    })


# ---------------------------
# Reports Sub-Pages
# ---------------------------
@login_required
def reports_daily(request: HttpRequest):
    """Daily reports page"""
    return render(request, 'tracker/reports_daily.html', {
        'page_title': 'Daily Reports',
        'today': timezone.localdate(),
    })

@login_required
def reports_monthly(request: HttpRequest):
    """Monthly reports page"""
    return render(request, 'tracker/reports_monthly.html', {
        'page_title': 'Monthly Reports',
        'current_month': timezone.localdate().strftime('%Y-%m'),
    })

@login_required
def reports_custom(request: HttpRequest):
    """Custom reports page"""
    return render(request, 'tracker/reports_custom.html', {
        'page_title': 'Custom Reports',
        'today': timezone.localdate(),
    })


# ---------------------------
# Inventory Sub-Pages
# ---------------------------
@login_required
def inventory_stock_management(request: HttpRequest):
    """Stock management page"""
    return render(request, 'tracker/inventory_stock_management.html', {
        'page_title': 'Stock Management',
        'today': timezone.localdate(),
    })

@login_required
def inventory_low_stock(request: HttpRequest):
    """Low stock alerts page"""
    return render(request, 'tracker/inventory_low_stock.html', {
        'page_title': 'Low Stock Alerts',
        'today': timezone.localdate(),
    })

@login_required
def inventory_suppliers(request: HttpRequest):
    """Suppliers management page"""
    return render(request, 'tracker/inventory_suppliers.html', {
        'page_title': 'Suppliers',
        'today': timezone.localdate(),
    })
